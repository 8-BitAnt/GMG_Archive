Get the latest!
http://iterationgames.com

this is just a demo leading up to the eventual release of;

Proper Third Dimentional Chess

demo CONTROLS:

Arrows to move the view around the board, . A or Z to move up/down,.
these are just crude hacks., needs loads of refinement!

I have been working on this game implementaion for many years now,.
It is my attempt to apply the rules of chess to 3D,. 8x8x8 board!

Eventialy we should have;

a 3d chess board so two ppl can play PTHChess on one machine,. 
on-line play,. live, or email based,. 
A.I. opponents for single player challanges..

likely a player finder server based system with rankings etc. as well.

this is a renderer speed test,. runs at 60fps here, if you get less please post your machine specs.


cheers,. 
jph



