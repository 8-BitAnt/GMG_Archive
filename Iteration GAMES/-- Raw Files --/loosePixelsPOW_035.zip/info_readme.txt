you must extract the files to run,. the .exe needs the .txt file to work!
you only need the ver. you want 1280X1024 fullscreen OR 800X600 windowed.

you may also run the windowed ver. in fullscreen by running it with -f (add to the name in a shotrcut)

win the game by clearing all pixels and catching all pows,. . just have some fun!

for more games go to;

 http://iterationGAMES.com




to build your own tinny .exe games use ZGameEditor !

 http://www.zgameeditor.org
