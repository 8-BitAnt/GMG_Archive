Joust 3 - Revenge of the Lava Troll
a fan game-remix by  jph wacheski 
wacheski@hotmail.com
http://iterationgames.com


THE CONTROLS:
press / hold LEFT and RIGHT arrows to control direction of flight.
(alternetly you can use 'A' and 'S' keys to control direction, for my Right Handed ppls!)
press the UP arrow (or the 'K' key) to flap.
press the DOWN arrow (or the 'L' key) to dive.

press the 'J' key to fire 'Stunner' cross-bow arrows!!!

A stunner will destroy a Bat, 
breifly stun a Buzzard, or a Raven-Head, 
and do very little to the "unbeatable?" Pterodactyl!
Collect 'Golden Eggs' to load more stunners.

press SPACE to pause the action.

'F5' saves the current 'state' of the game.
'F8' loads the game save 'state'.
press ENTER to quickly restart current level from the begining. (bypasses the gamma fx)

NOTE: it is advised that you save as you go along, likely several times on each level.
This is a part of the game play, and will cause you frustration, when you don't!!!

press the ESC key to go to the title screen,
then press again to leave the game.


For those of you young enough to not actually remember the 80s ;)  
When you hit hostiles if you are higher you win / if you are lower you lose!  Destroy the green eggs before they hatch by touching them.  You can also destroy the hatchlings before they get on a buzzard. 

HINT: if you haven't played Joust 2 'Servival of the Fittest' you may need this hint to finnish the game, the Black Knight can only be destroyed by smashing the four 'Pins' on his linbs!



Much respect to the creators of the original Joust (and the rarely seen sequal!).
I'm only making this remix because I loved that game back in the 80s.

Some graphics / sounds are addapted from the original games, and others created fresh by jph.
Some new music / sound design by Zug Island;  http://subverseco.com/zugisland
All codeing by jph!

Other ORIGINAL games created by jph are availible at;  http://iterationgames.com
Created using Game Maker by Mark Overmars;  http://www.gamemaker.nl  Respect!

                               This game will not to be sold!  
